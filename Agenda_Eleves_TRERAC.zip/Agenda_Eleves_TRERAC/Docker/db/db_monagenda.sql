-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : mysql:3306
-- Généré le : ven. 11 oct. 2024 à 14:19
-- Version du serveur : 8.0.30
-- Version de PHP : 8.0.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `db_monagenda`
--

-- --------------------------------------------------------

--
-- Structure de la table `t_schedule`
--

CREATE TABLE `t_schedule` (
  `idSchedule` varchar(255) NOT NULL,
  `schLink` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `t_schedule`
--

INSERT INTO `t_schedule` (`idSchedule`, `schLink`) VALUES
('dario.chasi@eduvaud.ch', 'https://eduvaud-my.sharepoint.com/:u:/g/personal/px86dym_eduvaud_ch/ERYdXjFywU5EqFZ1vOvA6DEBa6Fmq2geXfVvEmyr-Q5hLA?email=dario.chasi%40eduvaud.ch'),
('william.trelles1@eduvaud.ch', 'https://eduvaud-my.sharepoint.com/:u:/g/personal/px86dym_eduvaud_ch/EfC8S8_fn7BNpV7jsUf5Mk0BTVGyJzLq0HTqXXjHgOdYeQ?email=william.trelles1%40eduvaud.ch');

-- --------------------------------------------------------

--
-- Structure de la table `t_teacher`
--

CREATE TABLE `t_teacher` (
  `idTeacher` varchar(100) NOT NULL,
  `teaLink` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `t_schedule`
--
ALTER TABLE `t_schedule`
  ADD PRIMARY KEY (`idSchedule`);

--
-- Index pour la table `t_teacher`
--
ALTER TABLE `t_teacher`
  ADD PRIMARY KEY (`idTeacher`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
