# My Agenda ETML 📅 <br>
## Project Description 📃
Application "My Agenda" running with Microsoft Azure.
## &nbsp;Languages and Tools 🛠
![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?&style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?&style=for-the-badge&logo=css3&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23F7DF1E.svg?&style=for-the-badge&logo=javascript&logoColor=black) 

## Presentation
For this project we will use the Microsoft Azure services to configure our app.</br>
Microsoft Azure services will host your website, Database and the way to authenticate securely on it.

## What is MSAL authentication and how it works ?
or Microsoft Authentification Library,
Is used to secure your app, instead of creating your own authentification service you can use MSAL.
It makes more easier to integrate a authentification system into applications.
It alsow allows you to get security tokens from the Microsoft identity platform to allow users to authenticate to secured APIs.</br>
When you want to authenticate on a service, it will ask the token provider (MSAL) then if your credentials are valid MSAL will let you access the sercured APIs.
So in short we use MSAL as an authentification service to access the app.

## Explain the chosen functionalities DEV or Network 
We have choose Vue.JS to create the barometer in the app.<br>
In order to check if the barometer works, we edited the JSON files by adding late arrivals or absences.

## .env files explained
Those files are used to configure an environnement's variables that will be used in a running app,<br>
Like the Host, Port, User, Password, Database.<br>
It will allow you to access services like Microsoft Azure by using a Tenant ID, Client ID and Client Secret.<br>
Allowing sensitive data and configuration details (like credentials or system settings) to be managed separately from the app's code.<br>
<br>
If your secrets are publicly available, someone could take control of your cloud services, access your data, and use your personal ressources.<br>
So this is why it's mandatory to keep your .env file secret.

## Chosen Cloud Services Explained
We have choose Microsoft Azure as a cloud service.</br>
Because of it we can host our Agenda app on the cloud and access it on internet.</br>
With Microsoft Azure we can easily manage the database of the app and its ressources.</br>
It's also easily scalable, like if more people would use our website we can allow more ressources so it can handle it.

## Looking for other cloud alternatives or products ? 
We can use amazon's services or Facebook's services to host our app online.
## Add security elements ? 
We need to use an authentification service to login securely on our app.
## Using Paas service ? 
For this kind of service for an agenda, using a PAAS service works perfectly, since we only manage the data and the application.
## Concept of a « Mon Agenda de la semaine » and « Baromètre » page. 
given idea and final result :<br>
<img src="Documentation/images/MonHoraire.png" alt="Example" height="400">
.
<img src="Documentation/images/V2.png" alt="Example" height="400">

## Detailed Schematic of the App 
<img src="Documentation/images/sample.png" alt="Example" height="300"> 
Azure Hosts a web app that connects securely to a MySQL database. It uses a Virtual Network and Private Endpoint to keep all connections private, bypassing the public internet. The dashboard represents the app that will show the content of the database.

## Deliverables 📦
- Website Hosted on Microsoft Azure
- Technical Documentation 
- Dashboard of the Project 

- Project report with the following :
  - How the MSAL authentication works 
  - Explain the chosen functionalities DEV or INFRA 
  - Explain the .env file (content, production, how to use it) 
  - Explain the chosen Cloud Services 
  - Detailed Schematic of the App 

- Source code with comments on GitHub
- Be able to launch the App locally 
- Final Presentation

## How to use the project locally
1: Go in the Docker folder and type:
```bat
docker compose up
```
2: Go into the app folder then type:
```bat
npm install
```
and 
```bat
npm start
```
Now you can access the webstibe on the adress:
```bat
localhost:3000
```

## Sources used for this project
- https://bluefletch.com/intro-to-msal/</br>
- https://keyholesoftware.com/what-is-msal-and-how-does-it-work/</br>
- https://philna.sh/blog/2023/09/05/nodejs-supports-dotenv/</br>

Legend :<br>
Need to be done: ❌<br>
In progress: ⚪<br>
Done: ✔️<br>

Project by Thibaud Racine, William Trelles & Dario Chasi - ETML 2024
