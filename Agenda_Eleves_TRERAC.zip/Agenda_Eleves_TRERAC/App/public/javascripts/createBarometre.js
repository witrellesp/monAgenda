document.addEventListener("DOMContentLoaded", function() {
    const scheduleDataElement = document.getElementById('schedule-data');
    const jsonData = JSON.parse(scheduleDataElement.getAttribute('data-json'));
    const eleve = jsonData;


    createTableInDynamicContent(eleve);

    
    const totalAbsences = eleve.absences.length;
    const totalDays = eleve.courses.length;

    
    if (totalDays > 0) {
        updateBarometre(totalDays, totalAbsences);
    } else {
        console.error("Pas assez de données");
    }

    console.log(eleve);
});

function updateBarometre(totalDays, joursAbsents) {
    const pourcentageAbsence = (joursAbsents / totalDays) * 100;
    const barometro = document.getElementById('barometre');
    const pourcentageText = document.getElementById('absence-pourcentage');

    
    barometro.style.width = pourcentageAbsence + '%';
    pourcentageText.textContent = pourcentageAbsence.toFixed(1) + '%';

    
    if (pourcentageAbsence < 3) {
        barometro.style.backgroundColor = '#4caf50'; // Vert
    } else if (pourcentageAbsence < 6) {
        barometro.style.backgroundColor = '#ffa726'; // Orange
    } else {
        barometro.style.backgroundColor = '#ff6b6b'; // Rouge
    }
}
